"""
Market data fetching with intelligent caching.
Uses yfinance for OHLCV data with TTL-based caching to
avoid redundant API calls during auto-refresh cycles.
"""

import streamlit as st
import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta


# Default watchlist
DEFAULT_TICKERS = [
    "AAPL", "NVDA", "MSFT", "GOOGL", "AMZN", "META",
    "TSLA", "JPM", "V", "UNH", "LLY", "AVGO",
    "AMD", "NFLX", "CRM", "COST", "PEP", "INTC",
]

TICKER_META = {
    "AAPL": ("Apple Inc.", "Technology"),
    "NVDA": ("NVIDIA Corp.", "Semiconductors"),
    "MSFT": ("Microsoft Corp.", "Technology"),
    "GOOGL": ("Alphabet Inc.", "Technology"),
    "AMZN": ("Amazon.com Inc.", "Consumer"),
    "META": ("Meta Platforms", "Technology"),
    "TSLA": ("Tesla Inc.", "Automotive"),
    "JPM": ("JPMorgan Chase", "Finance"),
    "V": ("Visa Inc.", "Finance"),
    "UNH": ("UnitedHealth", "Healthcare"),
    "LLY": ("Eli Lilly", "Healthcare"),
    "AVGO": ("Broadcom Inc.", "Semiconductors"),
    "AMD": ("AMD Inc.", "Semiconductors"),
    "NFLX": ("Netflix Inc.", "Entertainment"),
    "CRM": ("Salesforce Inc.", "Technology"),
    "COST": ("Costco Wholesale", "Consumer"),
    "PEP": ("PepsiCo Inc.", "Consumer"),
    "INTC": ("Intel Corp.", "Semiconductors"),
}


@st.cache_data(ttl=300, show_spinner=False)
def fetch_stock_data(ticker: str, period: str = "6mo", interval: str = "1d") -> pd.DataFrame | None:
    """
    Fetch OHLCV data for a single ticker.

    Cached for 5 minutes to avoid API throttling during auto-refresh.
    Returns None on failure instead of raising.
    """
    try:
        data = yf.download(
            ticker,
            period=period,
            interval=interval,
            progress=False,
            auto_adjust=True,
            timeout=10,
        )
        if data.empty:
            return None
        # Flatten multi-level columns if present
        if isinstance(data.columns, pd.MultiIndex):
            data.columns = data.columns.get_level_values(0)
        return data
    except Exception:
        return None


@st.cache_data(ttl=300, show_spinner=False)
def fetch_batch_data(tickers: tuple, period: str = "6mo") -> dict[str, pd.DataFrame]:
    """
    Fetch data for multiple tickers efficiently.
    Returns dict of ticker -> DataFrame.
    """
    results = {}
    for t in tickers:
        df = fetch_stock_data(t, period=period)
        if df is not None and len(df) > 60:
            results[t] = df
    return results


@st.cache_data(ttl=60, show_spinner=False)
def fetch_intraday(ticker: str) -> pd.DataFrame | None:
    """Fetch 5-minute intraday data for real-time view."""
    try:
        data = yf.download(
            ticker,
            period="5d",
            interval="5m",
            progress=False,
            auto_adjust=True,
            timeout=10,
        )
        if data.empty:
            return None
        if isinstance(data.columns, pd.MultiIndex):
            data.columns = data.columns.get_level_values(0)
        return data
    except Exception:
        return None


def get_ticker_info(ticker: str) -> tuple[str, str]:
    """Return (name, sector) for a ticker."""
    return TICKER_META.get(ticker, (ticker, "Unknown"))
